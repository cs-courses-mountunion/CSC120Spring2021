/* 
 * CSC 120 Lecture 29
 *
 * EEK - Mice!
 *
 * 
 */
import java.awt.*;
import java.util.Random;
import javax.swing.*;

public class MUPanel extends JPanel {

    private Mouse theMouse, mickey, minnie, ratso;
    
    private Mouse[] vermin;
    
    private Random randGen;
    

    // constructor method
    public MUPanel() {
        setLayout(null);
        setPreferredSize(new Dimension(760, 640));
        setName("Mount Union Java Program");
        setUp();
        setBackground(new Color(0xe8, 0xe8, 0xcc));

        randGen = new Random();
        
        theMouse = new Mouse(100, 140, Color.YELLOW);
        mickey = new Mouse(300, 40, Color.CYAN);
        minnie = new Mouse(20, 240, Color.ORANGE);
        ratso = new Mouse(600, 200, Color.RED);
        
        mickey.turnAround();
        ratso.turnAround();
        

        vermin = new Mouse[150];
        
//        vermin[0] = new Mouse(50, 100, Color.PINK);
//        vermin[1] = new Mouse(60, 120, Color.YELLOW);
//        vermin[2] = new Mouse(70, 140, Color.ORANGE);
//        vermin[3] = new Mouse(80, 160, Color.GREEN);
//        vermin[4] = new Mouse(90, 180, Color.MAGENTA);

//        for (Integer index = 0; index < 20; index++) {
//            vermin[index] = new Mouse( index*10 + 50, index*20+100 );
//        }

        for (Integer index = 0; index < 150; index++) {
            Integer x = randGen.nextInt(601) + 100;
            Integer y = randGen.nextInt(501) + 50;
            Color c = Color.DARK_GRAY;
            Double pct = randGen.nextDouble();
            if (pct < 0.25) {
                c = Color.PINK;
            }
            else if (pct < 0.5) {
                c = Color.GREEN;
            }
            else if (pct < 0.75) {
                c = Color.BLUE;
            }
            vermin[index] = new Mouse( x, y );
            if (randGen.nextBoolean() == true) {
                vermin[index].turnAround();
            }
        }
        
    } // end of constructor
    
    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g); // This line must be first in this method!

   
        theMouse.draw(g);
        mickey.draw(g);
        minnie.draw(g);
        ratso.draw(g);
        	
        
        for (Integer index = 0; index < 150; index++) {
            vermin[index].draw(g);
        }
        
		
    } // end of paintComponent()
    
    
    public void moveMiceForward() {
   
        theMouse.moveForward(2);
        mickey.moveForward(2);
        minnie.moveForward(2);
        ratso.moveForward(2);

        for (Integer index = 0; index < 150; index++) {
            vermin[index].moveForward(2);
        }
        
    } // end of moveMiceForward
       
    public void turnMiceAround() {
        
        theMouse.turnAround();
        mickey.turnAround();
        minnie.turnAround();
        ratso.turnAround();

        for (Integer index = 0; index < 150; index+=2) {
            vermin[index].turnAround();
        }
        
    } // end of turnMiceAround
       
    
    
    
    /***********************************************
     * Do NOT change or delete anything below here!
     ***********************************************/
    public void setUp() {
        for (Component c: getComponents())
            c.setSize(c.getPreferredSize());
        JFrame f = new JFrame(getName());
        f.setContentPane(this);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.pack();
        f.setVisible(false);    
    }

    public static void main(String args[]){new MUPanel();}

} // end of class MUPanel
