/* 
 * CSC 120 Lecture 30
 *
 * EEK - Mice!
 *
 * 
 */
import java.awt.*;
import javax.swing.*;

public class MUPanel extends JPanel {

    private Mouse mickey;
    

    // constructor method
    public MUPanel() {
        setLayout(null);
        setPreferredSize(new Dimension(760, 640));
        setName("Mount Union Java Program");
        setUp();
        setBackground(new Color(0xe8, 0xe8, 0xcc));

        mickey = new Mouse(30, 140);

        
    } // end of constructor
    
    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g); // This line must be first in this method!

   
        mickey.draw(g);
		
		
    } // end of paintComponent()
    
    
    public void moveMiceForward() {
   
        mickey.moveForward(2);
        
    } // end of moveMiceForward
       
    public void turnMiceAround() {
        
        mickey.turnAround();
        
    } // end of turnMiceAround
       
    
    
    
    /***********************************************
     * Do NOT change or delete anything below here!
     ***********************************************/
    public void setUp() {
        for (Component c: getComponents())
            c.setSize(c.getPreferredSize());
        JFrame f = new JFrame(getName());
        f.setContentPane(this);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.pack();
        f.setVisible(false);    
    }

    public static void main(String args[]){new MUPanel();}

} // end of class MUPanel
